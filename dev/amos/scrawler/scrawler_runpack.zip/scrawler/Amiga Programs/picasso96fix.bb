;Set max display Width to 4096*4096
optimize 1:DEFTYPE.l
id=$50001000
While id <>-1
i.l=FindDisplayInfo_(id)
If i<>0
  i=Peek.l (i+$18)
  i=Peek.l (i+$34)
  Poke.l (i+$16),$10001000
End If
id=NextDisplayInfo_(id)
Wend


